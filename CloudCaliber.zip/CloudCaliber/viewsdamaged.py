from django.shortcuts import render
import os
import re
from django.utils.timezone import datetime
from django.utils.timezone import  timedelta
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from django.http import HttpRequest, HttpResponse
from django.contrib import messages
from django.shortcuts import redirect

import cloudcaliber_project.settings 
#import textutils.settings


from django.core.files.storage import FileSystemStorage
import threading as th 
from CloudCaliber import views
from CloudCaliber import viewsapi
from CloudCaliber import viewsidcreate
from CloudCaliber import views8d
from CloudCaliber import viewscalibrations
from CloudCaliber import viewsduecalendar 
from CloudCaliber import viewsduelist
from CloudCaliber import viewsgaugeusagewise
from CloudCaliber import viewsissuereturn
from CloudCaliber import viewsmasterlist
from CloudCaliber import viewsmasterlistdetails
from CloudCaliber import viewsmsastudy
from CloudCaliber import viewsuserlist
from CloudCaliber import viewsvalidations
from CloudCaliber import viewscategorycreation

from CloudCaliber.models import Adminoperatorlist, Masterinstrumentattachmentslist, Masterinstrumentcalibrationmasterslist, Masterinstrumentcalibrationsettingslist, Masterinstrumentenvironmentconditionlist, Masterinstrumentpartprojectslist,  Masterinstrumentpurchasechecklist, Masterinstrumentsparepartslist, Masterinstrumentslist 
# 
#from CloudCaliber.models import Admininstrumentmateriallist, Thistorytransactions, Thistorytransactionsmsa, Tmsaattributedatalist, Tmsabiasdatalist, Tmsalinearitydatalist, Tmsarnrdatalist, Tmsastabilitydatalist Tcalibrationhistorydetailslist, Tcalibrationhistorylist, Tcalibrationhistorymasterschecklistlist, Tcalibrationhistorymastersusedlist, Tdevicedamaged, Tdevicemissing, Tservicehistorylist, Ttraceissuereturnlist, Tutility8D0Emergencyactionlist, Tutility8D1Documentslist, Tutility8D1Teamdlist, Tutility8D3Containmentactionlist, Tutility8D4Rootcauselist, Tutility8D5Correctiveactionlist, Tutility8D6Implementcorrectiveactionlist, Tutility8D7Apreventiveactionlist, Tutility8D7Bprocesslist, Tutility8D7Creviewlist
#$, Tmsavisualdatalist Tpostpone, Tprepone, Tusagegaugedaily, Tverificationmain, Admin1Atrack, Admin1Companyinfo, Adminassetcategorylist, Adminassetcategorytypelist, Adminassetcategorytypelist1
from CloudCaliber.models import  Adminassetcategorytypelist1, Adminassetcategorylist, Adminassetcategorytypelist, Adminequipmentlist, Adminrangelist, Admininstrumenttypelist, Thistorytransactions, Adminassetsparepartslist, Adminassettypelist, Admincalibconditionslist, Adminexternalagencylist, Adminexternalagencytraceabilitylist, Admingradelist, Admininstrumentcattypelist, Admininstrumentequipmentlist, Admininstrumentmateriallist, Admininstrumentoperationlist, Admininstrumentrangelist, Adminlocationlist, Adminmakelist, Adminpartdetailslist, Adminpartdetailsforinstrumentlist, Adminpurchasechecklist, Adminrolelist, Adminstoragelocationlist, Admintoleranceclasschartlist, Admintoleranceclasslist, Admintoleranceclasschartlist
from CloudCaliber.models import Adminuseraccesslist, Adminassetcontinuousformatlist, Admininstrumentmateriallist, Admincustomerlist, Admintolerancedialgaugelist, Admintoleranceismanufacturingstdchartlist, Admintolerancepressuregaugelist, Admintoleranceradiusgaugelist, Admintolerancesettingringlist, Admintoleranceslipgaugelist, Adminunitlist, Adminunitofmeasurelist, Adminuserlist
#from CloudCaliber.models import Tutility8D8Followupmeetingslist, Tutility8Dlist, Tutilitydcdetailslist, Tutilitydclist
from CloudCaliber.models import Tservicehistory, Thistorymain, Thistorymainpart1, Thistorymainpart2, Masterinstrumentslist , Masterinstrumentslistpart2,   Masterinstrumentpreventivemabigintenancelist 



 
 
def GaugeRepairDetails(request, lID):
    

    if request.session:
        lLoginUserId = request.session['lLoginUserId'] 
        if(lLoginUserId==0):
            return   redirect('home') 
    else:
        return   redirect('home')  

        
    sCodeFinal1 = ""



    lPlantIdSelect = 0
    lPlantId = request.session['lunitid']  
    sPlantName = request.session['sunitno'] 
    lcompanyid = request.session['lcompanyid']  
    scompantname =  request.session['scompantname']  
    request.session['sPlantCode']   = ""
 
    lCategoryID = request.session['lCategoryID']                       
    lLoginUserId = request.session['lLoginUserId']  
    semployeename = request.session['semployeename'] 
    semployeeno = request.session['semployeeno']  
    lunitid = request.session['lunitid']  
    sunitno = request.session['sunitno']  
    lcompanyid = request.session['lcompanyid']  
    scompantname = request.session['scompantname']  
    semailaddress = request.session['semailaddress']  
    smobile = request.session['smobile']  

    # if request.session:
    #     request.session.clear()
 
 
    request.session['bSAPCodeDone']  = 0
    request.session['bSAPCodeNotDone']  = 0
    request.session['ID_Categories']  = 0
    request.session['ClassificationData']  = 0
    request.session['Flow1Data']  = 0
    request.session['Flow2Data']  = 0
    request.session['Flow3Data']  = 0
    request.session['Flow4Data']  = 0
    request.session['Flow5Data']  = 0
    request.session['GaugeClass']  = 0
    request.session['Location']  = 0 
    request.session['txtSearch']  = "" 

    CurDateFrom = datetime.today().strftime('%d-%m-%Y')
    request.session['CurDateFrom']  = CurDateFrom
    request.session['CurDateTo']  = CurDateFrom
    
    request.session['lCategoryID'] = lCategoryID                        
    request.session['lLoginUserId'] = lLoginUserId
    request.session['semployeename'] = semployeename
    request.session['semployeeno'] = semployeeno
    request.session['lunitid'] = lunitid
    request.session['sunitno']  = sunitno
    request.session['lcompanyid']  = lcompanyid
    request.session['scompantname']  = scompantname
    request.session['semailaddress'] = semailaddress
    request.session['smobile']  = smobile

    request.session['badmin'] =0
    request.session['badmin1'] = 0
    request.session['bstores'] = 0
    request.session['bcalibration'] = 0
    request.session['bservice'] = 0
    request.session['bmsa'] = 0
    request.session['bmasterlistonlyallplant'] = 1  
    request.session['breadonly'] =0
    sPlantCode = ""
    sCategoryCode = ""
    lcontinuousnob  = ""
    bFlow = 0
    sFlowName  = ""
    lcontinuousnoa  =0
    bFlow1 = 0
    sFlowName1  = ""
    lcontinuousnoa1  = 0
    bFlow2 = 0
    sFlowName2  = ""
    lcontinuousnoa2  =0
    bFlow3 = 0
    sFlowName3  = ""
    lcontinuousnoa3  =0
    bFlow4 = 0
    sFlowName4  = ""
    lcontinuousnoa4  =0
    bFlow5 = 0
    sFlowName5  = ""
    lcontinuousnoa5  =0
    bFlow6 = 0
    sFlowName6  = ""
    lcontinuousnoa6  =0
    bFlow7 = 0
    sFlowName7  = ""
    lcontinuousnoa7  =0
    bFlow8 = 0
    sFlowName8  = ""
    lcontinuousnoa8  =0
    bFlow9 = 0
    sFlowName9  = ""
    lcontinuousnoa9  =0
    bFlow10 = 0
    sFlowName10  = ""
    lcontinuousnoa10  =0
    
    bSAPCodeDone = 0
    bSAPCodeNotDone = 0

    cmbClassificationID = 0
    cmbCategoryID = 0
    cmbgetFlow1ID = 0
    cmbgetFlow2ID = 0
    cmbgetFlow3ID = 0
    cmbgetFlow4ID = 0
    cmbgetFlow5ID = 0
    cmbgetFlow6ID = 0
    
    getFlow1Code = ""
    request.session['getFlow1Code']  =getFlow1Code
    getFlow2Code = ""
    request.session['getFlow2Code']  =getFlow2Code
    getFlow3Code = ""
    request.session['getFlow3Code']  =getFlow3Code
    getFlow4Code = ""
    request.session['getFlow4Code']  =getFlow4Code
    getFlow5Code = ""
    request.session['getFlow5Code']  =getFlow5Code
    getFlowContCode = ""
    request.session['getFlowContCode']  =getFlowContCode


    bContFlag = 0
    request.session['bContFlag'] =bContFlag

    request.session['cmbClassificationID'] =cmbClassificationID
    request.session['cmbCategoryID'] =cmbCategoryID
    request.session['cmbgetFlow1ID'] =cmbgetFlow1ID
    request.session['cmbgetFlow2ID'] =cmbgetFlow2ID
    request.session['cmbgetFlow3ID'] =cmbgetFlow3ID
    request.session['cmbgetFlow4ID'] =cmbgetFlow4ID
    request.session['cmbgetFlow5ID'] =cmbgetFlow5ID
    request.session['cmbgetFlow6ID'] =cmbgetFlow6ID

    AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
    if AdminunitlistActive:
        sPlantCode = AdminunitlistActive.splantno
 
    request.session['sPlantCode']   =sPlantCode

    sCodeFinal1=""
    sCodeFinal2="-" + sPlantCode



    sReturnDate3 = ""
    sReturnDate2 = ""
    sReturnDate1 = ""
    sReturnDate = "" 
    dtReturnDate = datetime.now()
    sReturnDate1 = str(datetime.now()) 
    sReturnDate = sReturnDate1[0:10]

    if request.method == "POST":


        data = request.POST

    else:


        AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
        if AdminunitlistActive:
            sPlantCode = AdminunitlistActive.splantno
            sPlantNameName = AdminunitlistActive.splantname + " (" + AdminunitlistActive.scode.strip() + ")"
            sPlantNameNameA = AdminunitlistActive.splantname

        request.session['sPlantCode']   =sPlantCode
        
        Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ1 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:
            Adminassetcategorytypelist1_AddNewOBJ1 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=1 ).values()
            
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ2 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else: 
            Adminassetcategorytypelist1_AddNewOBJ2 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=2 ).values()
            
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ3 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ3 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=3 ).values()

        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ4 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ4 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=4 ).values()

        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ5 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ5 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=5 ).values()

        Adminassetcategorytypelist1_AddNewOBJ6 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=6 ).values()

        Admintoleranceclasslist_list =  Admintoleranceclasslist.objects.order_by('stoleranceclass')
        
        Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
        lunitidA=request.session['lunitid']  
        AreaofUselist_list = Adminlocationlist.objects.filter(lplantid=lunitidA).order_by('slocationname').values()     

        Masterinstrumentslist_list =  Masterinstrumentslist.objects.get(  lid=lID)

        

        Adminunitlist_list = Adminunitlist.objects.order_by('splantno')


        return render(request, "CloudCaliber/GaugeRepairDetails.html", 
        {
            'Masterinstrumentslist_listA':Masterinstrumentslist_list, 
            
            'CurDateNow':datetime.now(),
            'lPlantId':lPlantId,  
            '30DateNow':datetime.now() + timedelta(days=30),  
            'AreaofUselist_list':AreaofUselist_list,
            'Adminunitlist_list':Adminunitlist_list,
            'title':'User list', 
            'message':'Your User list page.',
            'sPlantName': sPlantName , 
            'Location': 0 , 
            'semployeename':  semployeename,
            'txtSearch': "" , 
            'sCodeFinal1': "" ,  
            'sCodeFinal2': "" ,  
            'cmbClassificationID': 0 , 
            'cmbCategoryID': 0 ,  
            'cmbFlow1ID': 0 ,  
            'cmbFlow2ID': 0 ,  
            'cmbFlow3ID': 0 ,  
            'cmbFlow4ID': 0 ,
            'cmbFlow5ID': 0 ,     
            'cmbFlow1label': "",  
            'cmbFlow2label': "",  
            'cmbFlow3label': "",  
            'cmbFlow4label': "",
            'cmbFlow5label': "",  
            'bNewID': 0 ,  
            'Adminassettypelist_list':Adminassettypelist_list,
            'bSAPCodeDone': bSAPCodeDone, 
            'bSAPCodeNotDone': bSAPCodeNotDone, 
            'sReturnDate': sReturnDate,
        }) 


 
def GaugeRepairHistoryDetails(request, lID):
    

    if request.session:
        lLoginUserId = request.session['lLoginUserId'] 
        if(lLoginUserId==0):
            return   redirect('home') 
    else:
        return   redirect('home')  

        
    sCodeFinal1 = ""



    lPlantIdSelect = 0
    lPlantId = request.session['lunitid']  
    sPlantName = request.session['sunitno'] 
    lcompanyid = request.session['lcompanyid']  
    scompantname =  request.session['scompantname']  
    request.session['sPlantCode']   = ""
 
    lCategoryID = request.session['lCategoryID']                       
    lLoginUserId = request.session['lLoginUserId']  
    semployeename = request.session['semployeename'] 
    semployeeno = request.session['semployeeno']  
    lunitid = request.session['lunitid']  
    sunitno = request.session['sunitno']  
    lcompanyid = request.session['lcompanyid']  
    scompantname = request.session['scompantname']  
    semailaddress = request.session['semailaddress']  
    smobile = request.session['smobile']  

    # if request.session:
    #     request.session.clear()
 
 
    request.session['bSAPCodeDone']  = 0
    request.session['bSAPCodeNotDone']  = 0
    request.session['ID_Categories']  = 0
    request.session['ClassificationData']  = 0
    request.session['Flow1Data']  = 0
    request.session['Flow2Data']  = 0
    request.session['Flow3Data']  = 0
    request.session['Flow4Data']  = 0
    request.session['Flow5Data']  = 0
    request.session['GaugeClass']  = 0
    request.session['Location']  = 0 
    request.session['txtSearch']  = "" 

    CurDateFrom = datetime.today().strftime('%d-%m-%Y')
    request.session['CurDateFrom']  = CurDateFrom
    request.session['CurDateTo']  = CurDateFrom
    
    request.session['lCategoryID'] = lCategoryID                        
    request.session['lLoginUserId'] = lLoginUserId
    request.session['semployeename'] = semployeename
    request.session['semployeeno'] = semployeeno
    request.session['lunitid'] = lunitid
    request.session['sunitno']  = sunitno
    request.session['lcompanyid']  = lcompanyid
    request.session['scompantname']  = scompantname
    request.session['semailaddress'] = semailaddress
    request.session['smobile']  = smobile

    request.session['badmin'] =0
    request.session['badmin1'] = 0
    request.session['bstores'] = 0
    request.session['bcalibration'] = 0
    request.session['bservice'] = 0
    request.session['bmsa'] = 0
    request.session['bmasterlistonlyallplant'] = 1  
    request.session['breadonly'] =0
    sPlantCode = ""
    sCategoryCode = ""
    lcontinuousnob  = ""
    bFlow = 0
    sFlowName  = ""
    lcontinuousnoa  =0
    bFlow1 = 0
    sFlowName1  = ""
    lcontinuousnoa1  = 0
    bFlow2 = 0
    sFlowName2  = ""
    lcontinuousnoa2  =0
    bFlow3 = 0
    sFlowName3  = ""
    lcontinuousnoa3  =0
    bFlow4 = 0
    sFlowName4  = ""
    lcontinuousnoa4  =0
    bFlow5 = 0
    sFlowName5  = ""
    lcontinuousnoa5  =0
    bFlow6 = 0
    sFlowName6  = ""
    lcontinuousnoa6  =0
    bFlow7 = 0
    sFlowName7  = ""
    lcontinuousnoa7  =0
    bFlow8 = 0
    sFlowName8  = ""
    lcontinuousnoa8  =0
    bFlow9 = 0
    sFlowName9  = ""
    lcontinuousnoa9  =0
    bFlow10 = 0
    sFlowName10  = ""
    lcontinuousnoa10  =0
    
    bSAPCodeDone = 0
    bSAPCodeNotDone = 0

    cmbClassificationID = 0
    cmbCategoryID = 0
    cmbgetFlow1ID = 0
    cmbgetFlow2ID = 0
    cmbgetFlow3ID = 0
    cmbgetFlow4ID = 0
    cmbgetFlow5ID = 0
    cmbgetFlow6ID = 0
    
    getFlow1Code = ""
    request.session['getFlow1Code']  =getFlow1Code
    getFlow2Code = ""
    request.session['getFlow2Code']  =getFlow2Code
    getFlow3Code = ""
    request.session['getFlow3Code']  =getFlow3Code
    getFlow4Code = ""
    request.session['getFlow4Code']  =getFlow4Code
    getFlow5Code = ""
    request.session['getFlow5Code']  =getFlow5Code
    getFlowContCode = ""
    request.session['getFlowContCode']  =getFlowContCode


    bContFlag = 0
    request.session['bContFlag'] =bContFlag

    request.session['cmbClassificationID'] =cmbClassificationID
    request.session['cmbCategoryID'] =cmbCategoryID
    request.session['cmbgetFlow1ID'] =cmbgetFlow1ID
    request.session['cmbgetFlow2ID'] =cmbgetFlow2ID
    request.session['cmbgetFlow3ID'] =cmbgetFlow3ID
    request.session['cmbgetFlow4ID'] =cmbgetFlow4ID
    request.session['cmbgetFlow5ID'] =cmbgetFlow5ID
    request.session['cmbgetFlow6ID'] =cmbgetFlow6ID

    AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
    if AdminunitlistActive:
        sPlantCode = AdminunitlistActive.splantno
 
    request.session['sPlantCode']   =sPlantCode

    sCodeFinal1=""
    sCodeFinal2="-" + sPlantCode



    sReturnDate3 = ""
    sReturnDate2 = ""
    sReturnDate1 = ""
    sReturnDate = "" 
    dtReturnDate = datetime.now()
    sReturnDate1 = str(datetime.now()) 
    sReturnDate = sReturnDate1[0:10]

    if request.method == "POST":


        data = request.POST

    else:


        AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
        if AdminunitlistActive:
            sPlantCode = AdminunitlistActive.splantno
            sPlantNameName = AdminunitlistActive.splantname + " (" + AdminunitlistActive.scode.strip() + ")"
            sPlantNameNameA = AdminunitlistActive.splantname

        request.session['sPlantCode']   =sPlantCode
        
        Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ1 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:
            Adminassetcategorytypelist1_AddNewOBJ1 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=1 ).values()
            
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ2 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else: 
            Adminassetcategorytypelist1_AddNewOBJ2 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=2 ).values()
            
        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ3 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ3 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=3 ).values()

        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ4 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ4 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=4 ).values()

        if(sFlowName1 == "Part No1"):
            Adminassetcategorytypelist1_AddNewOBJ5 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
        else:  
            Adminassetcategorytypelist1_AddNewOBJ5 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=5 ).values()

        Adminassetcategorytypelist1_AddNewOBJ6 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=6 ).values()

        Admintoleranceclasslist_list =  Admintoleranceclasslist.objects.order_by('stoleranceclass')
        
        Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
        lunitidA=request.session['lunitid']  
        AreaofUselist_list = Adminlocationlist.objects.filter(lplantid=lunitidA).order_by('slocationname').values()     

        Masterinstrumentslist_list =  Masterinstrumentslist.objects.get(  lid=lID)

        

        Adminunitlist_list = Adminunitlist.objects.order_by('splantno')


        return render(request, "CloudCaliber/GaugeRepairDetails.html", 
        {
            'Masterinstrumentslist_listA':Masterinstrumentslist_list, 
            
            'CurDateNow':datetime.now(),
            'lPlantId':lPlantId,  
            '30DateNow':datetime.now() + timedelta(days=30),  
            'AreaofUselist_list':AreaofUselist_list,
            'Adminunitlist_list':Adminunitlist_list,
            'title':'User list', 
            'message':'Your User list page.',
            'sPlantName': sPlantName , 
            'Location': 0 , 
            'semployeename':  semployeename,
            'txtSearch': "" , 
            'sCodeFinal1': "" ,  
            'sCodeFinal2': "" ,  
            'cmbClassificationID': 0 , 
            'cmbCategoryID': 0 ,  
            'cmbFlow1ID': 0 ,  
            'cmbFlow2ID': 0 ,  
            'cmbFlow3ID': 0 ,  
            'cmbFlow4ID': 0 ,
            'cmbFlow5ID': 0 ,     
            'cmbFlow1label': "",  
            'cmbFlow2label': "",  
            'cmbFlow3label': "",  
            'cmbFlow4label': "",
            'cmbFlow5label': "",  
            'bNewID': 0 ,  
            'Adminassettypelist_list':Adminassettypelist_list,
            'bSAPCodeDone': bSAPCodeDone, 
            'bSAPCodeNotDone': bSAPCodeNotDone, 
            'sReturnDate': sReturnDate,
        }) 





def GaugeServiceRepair1(request):

    if request.session:
        lLoginUserId = request.session['lLoginUserId'] 
        if(lLoginUserId==0):
            return   redirect('home') 
    else:
        return   redirect('home')  

        
    lID =0
    lID = int(request.session['InstIDRepair'])
    return redirect("GaugeServiceRepair", lID=lID) 





def GaugeServiceRepair(request, lID):
    

    if request.session:
        lLoginUserId = request.session['lLoginUserId'] 
        if(lLoginUserId==0):
            return   redirect('home') 
    else:
        return   redirect('home')  

        
    sCodeFinal1 = ""
    sCodeFinal2 = ""
 
    historyserviceid = 0
    

    historyserviceid = 0
    linstrumentid = 0
    lscheduleid = 0
    sinstrumentcode = ""
    sinstrumentdesc = ""
    brepair = 0
    scurrentstatus = ""
    sserviceresult = ""
    dtservicedate = datetime.today()
    fservicecost = 0
    stimetaken = ""
    sdevicecondition = ""
    lenteredid = 0
    senteredby = ""
    lapprovedid = 0
    sapprovedby = ""
    dtapprovaldate = datetime.today()
    scertificateno = ""
    scomments = ""
    lservicevendorid = 0
    sservicevendor = ""
    spurchaseorderno = ""
    sservicecertificatefile = ""
    sservicecertificatepath = ""
    dtdispatchdate = datetime.today()
    dtduedate = datetime.today()
    lusedbyid = 0
    susedbyname = ""
    bapproved = 0
    brefdatail = 0
    dvendor = datetime.today()
    drefdate = datetime.today()
    fpmcost = 0
    lplantid = 0
    splantname = ""
    splantcode = ""
    lcompanyid = 0
    lnoticedbyid = 0
    snoticedbyname = ""
    sreason = ""
    dtdateofnotice = datetime.today()
    llocationid = 0
    slocationname = ""
    brejected = 0
    bsentforrepair = 0
    ldcrefid = 0
    sservicedate = ""
    sapprovaldate = ""
    sdispatchdate = ""
    sduedate = ""
    srefdate = ""
    sdateofnotice = ""
    bdvendor = 0





    request.session['InstIDRepair']  = 0

    lPlantIdSelect = 0
    lPlantId = request.session['lunitid']  
    sPlantName = request.session['sunitno'] 
    lcompanyid = request.session['lcompanyid']  
    scompantname =  request.session['scompantname']  
    request.session['sPlantCode']   = ""
 
    lCategoryID = request.session['lCategoryID']                       
    lLoginUserId = request.session['lLoginUserId']  
    semployeename = request.session['semployeename'] 
    semployeeno = request.session['semployeeno']  
    lunitid = request.session['lunitid']  
    sunitno = request.session['sunitno']  
    lcompanyid = request.session['lcompanyid']  
    scompantname = request.session['scompantname']  
    semailaddress = request.session['semailaddress']  
    smobile = request.session['smobile']  
    

    # if request.session:
    #     request.session.clear()
 
 
    request.session['InstIDRepair']  = 0
    request.session['bSAPCodeDone']  = 0
    request.session['bSAPCodeNotDone']  = 0
    request.session['ID_Categories']  = 0
    request.session['ClassificationData']  = 0
    request.session['Flow1Data']  = 0
    request.session['Flow2Data']  = 0
    request.session['Flow3Data']  = 0
    request.session['Flow4Data']  = 0
    request.session['Flow5Data']  = 0
    request.session['GaugeClass']  = 0
    request.session['Location']  = 0 
    request.session['txtSearch']  = "" 

    CurDateFrom = datetime.today().strftime('%d-%m-%Y')
    request.session['CurDateFrom']  = CurDateFrom
    request.session['CurDateTo']  = CurDateFrom
    
    request.session['lCategoryID'] = lCategoryID                        
    request.session['lLoginUserId'] = lLoginUserId
    request.session['semployeename'] = semployeename
    request.session['semployeeno'] = semployeeno
    request.session['lunitid'] = lunitid
    request.session['sunitno']  = sunitno
    request.session['lcompanyid']  = lcompanyid
    request.session['scompantname']  = scompantname
    request.session['semailaddress'] = semailaddress
    request.session['smobile']  = smobile

    #semployeename = semployeeno + " | " + semployeename
    request.session['badmin'] =0
    request.session['badmin1'] = 0
    request.session['bstores'] = 0
    request.session['bcalibration'] = 0
    request.session['bservice'] = 0
    request.session['bmsa'] = 0
    request.session['bmasterlistonlyallplant'] = 1  
    request.session['breadonly'] =0
    sPlantCode = ""
    sCategoryCode = ""
    lcontinuousnob  = ""
    bFlow = 0
    sFlowName  = ""
    lcontinuousnoa  =0
    bFlow1 = 0
    sFlowName1  = ""
    lcontinuousnoa1  = 0
    bFlow2 = 0
    sFlowName2  = ""
    lcontinuousnoa2  =0
    bFlow3 = 0
    sFlowName3  = ""
    lcontinuousnoa3  =0
    bFlow4 = 0
    sFlowName4  = ""
    lcontinuousnoa4  =0
    bFlow5 = 0
    sFlowName5  = ""
    lcontinuousnoa5  =0
    bFlow6 = 0
    sFlowName6  = ""
    lcontinuousnoa6  =0
    bFlow7 = 0
    sFlowName7  = ""
    lcontinuousnoa7  =0
    bFlow8 = 0
    sFlowName8  = ""
    lcontinuousnoa8  =0
    bFlow9 = 0
    sFlowName9  = ""
    lcontinuousnoa9  =0
    bFlow10 = 0
    sFlowName10  = ""
    lcontinuousnoa10  =0
    
    bSAPCodeDone = 0
    bSAPCodeNotDone = 0

    cmbClassificationID = 0
    cmbCategoryID = 0
    cmbgetFlow1ID = 0
    cmbgetFlow2ID = 0
    cmbgetFlow3ID = 0
    cmbgetFlow4ID = 0
    cmbgetFlow5ID = 0
    cmbgetFlow6ID = 0
    

    sIssueDate3 = ""
    sIssueDate2 = ""
    sIssueDate1 = ""
    sIssueDate = "" 
    dtIssueDate = datetime.now()
    sIssueDate1 = str(datetime.now()) 
    sIssueDate = sIssueDate1[0:10]


    getFlow1Code = ""
    request.session['getFlow1Code']  =getFlow1Code
    getFlow2Code = ""
    request.session['getFlow2Code']  =getFlow2Code
    getFlow3Code = ""
    request.session['getFlow3Code']  =getFlow3Code
    getFlow4Code = ""
    request.session['getFlow4Code']  =getFlow4Code
    getFlow5Code = ""
    request.session['getFlow5Code']  =getFlow5Code
    getFlowContCode = ""
    request.session['getFlowContCode']  =getFlowContCode


    bContFlag = 0
    request.session['bContFlag'] =bContFlag

    request.session['cmbClassificationID'] =cmbClassificationID
    request.session['cmbCategoryID'] =cmbCategoryID
    request.session['cmbgetFlow1ID'] =cmbgetFlow1ID
    request.session['cmbgetFlow2ID'] =cmbgetFlow2ID
    request.session['cmbgetFlow3ID'] =cmbgetFlow3ID
    request.session['cmbgetFlow4ID'] =cmbgetFlow4ID
    request.session['cmbgetFlow5ID'] =cmbgetFlow5ID
    request.session['cmbgetFlow6ID'] =cmbgetFlow6ID

    AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
    if AdminunitlistActive:
        sPlantCode = AdminunitlistActive.splantno
 
    request.session['sPlantCode']   =sPlantCode

    sCodeFinal1=""
    sCodeFinal2="-" + sPlantCode

    Masterinstrumentslist_listAGET =  Masterinstrumentslist.objects.get(  lid=lID)
    if Masterinstrumentslist_listAGET:

        if(Masterinstrumentslist_listAGET.bunderrepair == 1):
            historyserviceid =0
            linstrumentid = lID
            historyserviceid = Masterinstrumentslist_listAGET.lrepairid
            
    if request.method == "POST":


        data = request.POST
        bSAPCodeDone = 0
 
 

        txtRepairCost=0
        if 'txtRepairCost' in request.POST:
            txtRepairCost = data.get("txtRepairCost")

        txtRepairDate=""
        if 'txtRepairDate' in request.POST:
            txtRepairDate = data.get("txtRepairDate")
        if(txtRepairDate == ""): 
            txtRepairDate =str(datetime.now()) 
            txtRepairDate = txtRepairDate[0:10] 
 

        txtCauseofDamage = ""
        if 'txtCauseofDamage' in request.POST:
            txtCauseofDamage = data.get("txtCauseofDamage")

        txtRepairDetails = ""
        if 'txtRepairDetails' in request.POST:
            txtRepairDetails = data.get("txtRepairDetails")
            



        txtRepairDoneBy = ""
        if 'txtRepairDoneBy' in request.POST:
            txtRepairDoneBy = data.get("txtRepairDoneBy")



        txtRepairRefNo = ""
        if 'txtRepairRefNo' in request.POST:
            txtRepairRefNo = data.get("txtRepairRefNo")



        txtRepairVendorRef = ""
        if 'txtRepairVendorRef' in request.POST:
            txtRepairVendorRef = data.get("txtRepairVendorRef")



        cmbReturnStatus = ""
        if 'cmbReturnStatus' in request.POST:
            cmbReturnStatus = data.get("cmbReturnStatus")
             



        
        if 'cmbClose' in request.POST: 
            return   redirect('Dashboard')  


        if 'checklistPDF' in request.FILES:
            if  request.method == 'POST' and request.FILES['checklistPDF']: 
              
                #request.session['lhistorymainid'] = lID
                myfile = request.FILES['checklistPDF']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                uploaded_file_url = fs.url(filename)
                filenamePath = "/media/" + filename
                #filepath =  BASE_DIR + filenamePath
                
 
            TservicehistorySave = Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            fpmcost = 0
            fpmcost =txtRepairCost
            
            linstrumentid = lID
            lscheduleid = 0
            sinstrumentcode = ""
            sinstrumentdesc = ""
            Masterinstrumentslist_listAQW =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            if Masterinstrumentslist_listAQW:                
                sinstrumentid = Masterinstrumentslist_listAQW.sinstrumentid
                sinstrumentDesc = Masterinstrumentslist_listAQW.sdescription
            
            sinstrumentcode=sinstrumentid
            historyserviceid = 0

            brepair = 1
            scurrentstatus = cmbReturnStatus 
            dtservicedate = txtRepairDate 
            lenteredid = 0
            senteredby = request.session['semployeeno'] + "|" + request.session['semployeename']
            lenteredid =  request.session['lLoginUserId'] 
            scauseofdamage = txtCauseofDamage
            srepairdetails = txtRepairDetails
            srepairdoneby = txtRepairDoneBy
            srepairpodcref = txtRepairRefNo
            srepairdcdate = ""
            srepairreturnrefno = txtRepairVendorRef
            srepairreturndate = ""

            Masterinstrumentslist_listSaveDamaged =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            historyserviceid = Masterinstrumentslist_listSaveDamaged.lrepairid 
            TservicehistoryUpdate =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            TservicehistoryUpdate.sservicecertificatefile1 =filenamePath
            TservicehistoryUpdate.scauseofdamage = scauseofdamage
            TservicehistoryUpdate.srepairdetails = srepairdetails
            TservicehistoryUpdate.srepairdoneby = srepairdoneby
            TservicehistoryUpdate.srepairpodcref = txtRepairRefNo 
            TservicehistoryUpdate.srepairreturnrefno = txtRepairVendorRef 

            TservicehistoryUpdate.fpmcost = fpmcost 

            TservicehistoryUpdate.scurrentstatus = scurrentstatus 
            TservicehistoryUpdate.dtservicedate = dtservicedate 
            TservicehistoryUpdate.senteredby = senteredby
            TservicehistoryUpdate.lenteredid =  lenteredid 

            TservicehistoryUpdate.save()
 
            request.session['InstIDRepair']=lID
            messages.success(request, 'Repair Document is Uploaded & Saved')

            return redirect('GaugeServiceRepair1')  


        if 'checklistPDF1' in request.FILES:
            if  request.method == 'POST' and request.FILES['checklistPDF1']: 
              
                #request.session['lhistorymainid'] = lID
                myfile = request.FILES['checklistPDF1']
                fs = FileSystemStorage()
                filename = fs.save(myfile.name, myfile)
                BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                uploaded_file_url = fs.url(filename)
                filenamePath = "/media/" + filename
                #filepath =  BASE_DIR + filenamePath
                
 
            TservicehistorySave = Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            
            linstrumentid = lID
            lscheduleid = 0
            sinstrumentcode = ""
            sinstrumentdesc = ""
            Masterinstrumentslist_listAQW =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            if Masterinstrumentslist_listAQW:                
                sinstrumentid = Masterinstrumentslist_listAQW.sinstrumentid
                sinstrumentDesc = Masterinstrumentslist_listAQW.sdescription
            
            sinstrumentcode=sinstrumentid
            historyserviceid = 0

            fpmcost = 0
            fpmcost =txtRepairCost
            brepair = 1
            scurrentstatus = cmbReturnStatus 
            dtservicedate = txtRepairDate 
            lenteredid = 0
            senteredby = request.session['semployeeno'] + "|" + request.session['semployeename']
            lenteredid =  request.session['lLoginUserId'] 
            scauseofdamage = txtCauseofDamage
            srepairdetails = txtRepairDetails
            srepairdoneby = txtRepairDoneBy
            srepairpodcref = txtRepairRefNo
            srepairdcdate = ""
            srepairreturnrefno = txtRepairVendorRef
            srepairreturndate = ""

            Masterinstrumentslist_listSaveDamaged =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            historyserviceid = Masterinstrumentslist_listSaveDamaged.lrepairid 
            TservicehistoryUpdate =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            TservicehistoryUpdate.sservicecertificatefile2 =filenamePath
            TservicehistoryUpdate.scauseofdamage = scauseofdamage
            TservicehistoryUpdate.srepairdetails = srepairdetails
            TservicehistoryUpdate.srepairdoneby = srepairdoneby
            TservicehistoryUpdate.srepairpodcref = txtRepairRefNo 
            TservicehistoryUpdate.srepairreturnrefno = txtRepairVendorRef 
            TservicehistoryUpdate.fpmcost = fpmcost 

            TservicehistoryUpdate.scurrentstatus = scurrentstatus 
            TservicehistoryUpdate.dtservicedate = dtservicedate 
            TservicehistoryUpdate.senteredby = senteredby
            TservicehistoryUpdate.lenteredid =  lenteredid 

            TservicehistoryUpdate.save()
 

            request.session['InstIDRepair']=lID
            messages.success(request, 'Repair Document is Uploaded & Saved')

            return redirect('GaugeServiceRepair1')  




        if 'cmbSaveRepair' in request.POST: 
            
            TservicehistorySave = Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            
            linstrumentid = lID
            lscheduleid = 0
            sinstrumentcode = ""
            sinstrumentdesc = ""
            Masterinstrumentslist_listAQW =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            if Masterinstrumentslist_listAQW:                
                sinstrumentid = Masterinstrumentslist_listAQW.sinstrumentid
                sinstrumentDesc = Masterinstrumentslist_listAQW.sdescription
            
            sinstrumentcode=sinstrumentid
            historyserviceid = 0

            brepair = 1
            scurrentstatus = cmbReturnStatus 
            dtservicedate = txtRepairDate 
            lenteredid = 0
            senteredby = request.session['semployeeno'] + "|" + request.session['semployeename']
            lenteredid =  request.session['lLoginUserId'] 
            scauseofdamage = txtCauseofDamage
            srepairdetails = txtRepairDetails
            srepairdoneby = txtRepairDoneBy
            srepairpodcref = txtRepairRefNo
            srepairdcdate = ""
            srepairreturnrefno = txtRepairVendorRef
            srepairreturndate = ""
            fpmcost = 0
            fpmcost =txtRepairCost

            Masterinstrumentslist_listSaveDamaged =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            historyserviceid = Masterinstrumentslist_listSaveDamaged.lrepairid 
            TservicehistoryUpdate =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            TservicehistoryUpdate.scauseofdamage = scauseofdamage
            TservicehistoryUpdate.srepairdetails = srepairdetails
            TservicehistoryUpdate.srepairdoneby = srepairdoneby
            TservicehistoryUpdate.srepairpodcref = txtRepairRefNo 
            TservicehistoryUpdate.srepairreturnrefno = txtRepairVendorRef 

            TservicehistoryUpdate.scurrentstatus = scurrentstatus 
            TservicehistoryUpdate.dtservicedate = dtservicedate 
            TservicehistoryUpdate.senteredby = senteredby
            TservicehistoryUpdate.lenteredid =  lenteredid 
            TservicehistoryUpdate.fpmcost = fpmcost 

            TservicehistoryUpdate.save()

            request.session['InstIDRepair']=lID

            
            messages.success(request, 'Repair Details is Saved')

            return redirect('GaugeServiceRepair1')  



 

        if 'cmbApproveRepair' in request.POST: 
        
            if(cmbReturnStatus == ""):

                
                messages.error(request, 'Status is not selected. Please select Repair status / condition and Save')

                Masterinstrumentslist_listA =  Masterinstrumentslist.objects.get(  lid=lID)
                if Masterinstrumentslist_listA:

                    if(Masterinstrumentslist_listA.bunderrepair == 1):
                        historyserviceid =0
                        linstrumentid = lID
                        historyserviceid = Masterinstrumentslist_listA.lrepairid
                        Tservicehistory_listA =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)
                        if Tservicehistory_listA:

                            if(Tservicehistory_listA.bapproved == 1):
                                
                                historyserviceid =0

                                linstrumentid = lID
                                lscheduleid = 0
                                sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                                sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                                brepair = 0
                                scurrentstatus = ""
                                sserviceresult = ""
                                dtservicedate = datetime.now()
                                fservicecost = 0
                                stimetaken = ""
                                sdevicecondition = ""
                                lenteredid = 0
                                senteredby = ""
                                lapprovedid = 0
                                sapprovedby = ""
                                dtapprovaldate = datetime.now()
                                scertificateno = ""
                                scomments = ""
                                lservicevendorid = 0
                                sservicevendor = ""
                                spurchaseorderno = ""
                                sservicecertificatefile = ""
                                sservicecertificatepath = ""
                                dtdispatchdate = datetime.now()
                                dtduedate = datetime.now()
                                lusedbyid = 0
                                susedbyname = ""
                                bapproved = 0
                                brefdatail = 0
                                dvendor = datetime.now()
                                drefdate = datetime.now()
                                fpmcost = 0
                                lplantid = 0
                                splantname = ""
                                splantcode = ""
                                lcompanyid = 0
                                lnoticedbyid = 0
                                snoticedbyname = ""
                                sreason = ""
                                dtdateofnotice = datetime.now()
                                llocationid = 0
                                slocationname = ""
                                brejected = 0
                                bsentforrepair = 0
                                ldcrefid = 0
                                sservicedate = ""
                                sapprovaldate = ""
                                sdispatchdate = ""
                                sduedate = ""
                                srefdate = ""
                                sdateofnotice = ""
                                bdvendor = 0


                                        
                                TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                                TservicehistorySave.save()
                                historyserviceid = TservicehistorySave.historyserviceid

                                Masterinstrumentslist_listA.bunderrepair =1
                                Masterinstrumentslist_listA.lrepairid =historyserviceid
                                Masterinstrumentslist_listA.save()
                        
                            else:
                                
                                historyserviceid = Tservicehistory_listA.historyserviceid

                        else:


                            linstrumentid = lID
                            lscheduleid = 0
                            sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                            sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                            brepair = 0
                            scurrentstatus = ""
                            sserviceresult = ""
                            dtservicedate = datetime.now()
                            fservicecost = 0
                            stimetaken = ""
                            sdevicecondition = ""
                            lenteredid = 0
                            senteredby = ""
                            lapprovedid = 0
                            sapprovedby = ""
                            dtapprovaldate = datetime.now()
                            scertificateno = ""
                            scomments = ""
                            lservicevendorid = 0
                            sservicevendor = ""
                            spurchaseorderno = ""
                            sservicecertificatefile = ""
                            sservicecertificatepath = ""
                            dtdispatchdate = datetime.now()
                            dtduedate = datetime.now()
                            lusedbyid = 0
                            susedbyname = ""
                            bapproved = 0
                            brefdatail = 0
                            dvendor = datetime.now()
                            drefdate = datetime.now()
                            fpmcost = 0
                            lplantid = 0
                            splantname = ""
                            splantcode = ""
                            lcompanyid = 0
                            lnoticedbyid = 0
                            snoticedbyname = ""
                            sreason = ""
                            dtdateofnotice = datetime.now()
                            llocationid = 0
                            slocationname = ""
                            brejected = 0
                            bsentforrepair = 0
                            ldcrefid = 0
                            sservicedate = ""
                            sapprovaldate = ""
                            sdispatchdate = ""
                            sduedate = ""
                            srefdate = ""
                            sdateofnotice = ""
                            bdvendor = 0


                                    
                            TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                            TservicehistorySave.save()
                            historyserviceid = TservicehistorySave.historyserviceid

                            Masterinstrumentslist_listA.bunderrepair =1
                            Masterinstrumentslist_listA.lrepairid =historyserviceid
                            Masterinstrumentslist_listA.save()


                    if(Masterinstrumentslist_listA.bunderrepair == 0):
                        historyserviceid = 0




                        linstrumentid = lID
                        lscheduleid = 0
                        sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                        sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                        brepair = 0
                        scurrentstatus = ""
                        sserviceresult = ""
                        dtservicedate = datetime.now()
                        fservicecost = 0
                        stimetaken = ""
                        sdevicecondition = ""
                        lenteredid = 0
                        senteredby = ""
                        lapprovedid = 0
                        sapprovedby = ""
                        dtapprovaldate = datetime.now()
                        scertificateno = ""
                        scomments = ""
                        lservicevendorid = 0
                        sservicevendor = ""
                        spurchaseorderno = ""
                        sservicecertificatefile = ""
                        sservicecertificatepath = ""
                        dtdispatchdate = datetime.now()
                        dtduedate = datetime.now()
                        lusedbyid = 0
                        susedbyname = ""
                        bapproved = 0
                        brefdatail = 0
                        dvendor = datetime.now()
                        drefdate = datetime.now()
                        fpmcost = 0
                        lplantid = 0
                        splantname = ""
                        splantcode = ""
                        lcompanyid = 0
                        lnoticedbyid = 0
                        snoticedbyname = ""
                        sreason = ""
                        dtdateofnotice = datetime.now()
                        llocationid = 0
                        slocationname = ""
                        brejected = 0
                        bsentforrepair = 0
                        ldcrefid = 0
                        sservicedate = ""
                        sapprovaldate = ""
                        sdispatchdate = ""
                        sduedate = ""
                        srefdate = ""
                        sdateofnotice = ""
                        bdvendor = 0


                                
                        TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                        TservicehistorySave.save()
                        historyserviceid = TservicehistorySave.historyserviceid

                        Masterinstrumentslist_listA.bunderrepair =1
                        Masterinstrumentslist_listA.lrepairid =historyserviceid
                        Masterinstrumentslist_listA.save()

        
                
                AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
                if AdminunitlistActive:
                    sPlantCode = AdminunitlistActive.splantno
                    sPlantNameName = AdminunitlistActive.splantname + " (" + AdminunitlistActive.scode.strip() + ")"
                    sPlantNameNameA = AdminunitlistActive.splantname

                request.session['sPlantCode']   =sPlantCode
                
                Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
                if(sFlowName1 == "Part No1"):
                    Adminassetcategorytypelist1_AddNewOBJ1 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
                else:
                    Adminassetcategorytypelist1_AddNewOBJ1 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=1 ).values()
                    
                if(sFlowName1 == "Part No1"):
                    Adminassetcategorytypelist1_AddNewOBJ2 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
                else: 
                    Adminassetcategorytypelist1_AddNewOBJ2 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=2 ).values()
                    
                if(sFlowName1 == "Part No1"):
                    Adminassetcategorytypelist1_AddNewOBJ3 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
                else:  
                    Adminassetcategorytypelist1_AddNewOBJ3 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=3 ).values()

                if(sFlowName1 == "Part No1"):
                    Adminassetcategorytypelist1_AddNewOBJ4 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
                else:  
                    Adminassetcategorytypelist1_AddNewOBJ4 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=4 ).values()

                if(sFlowName1 == "Part No1"):
                    Adminassetcategorytypelist1_AddNewOBJ5 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
                else:  
                    Adminassetcategorytypelist1_AddNewOBJ5 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=5 ).values()

                Adminassetcategorytypelist1_AddNewOBJ6 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=6 ).values()

                Admintoleranceclasslist_list =  Admintoleranceclasslist.objects.order_by('stoleranceclass')
                
                Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
                lunitidA=request.session['lunitid']  
                AreaofUselist_list = Adminlocationlist.objects.filter(lplantid=lunitidA).order_by('slocationname').values()     

                Masterinstrumentslist_list =  Masterinstrumentslist.objects.get(  lid=lID)
        
                
                Adminunitlist_list = Adminunitlist.objects.order_by('splantno')

                TservicehistoryActive = Tservicehistory.objects.get(historyserviceid=historyserviceid) 
                

        
                return render(request, "CloudCaliber/GaugeServiceRepair.html", 
                {
                    'Masterinstrumentslist_listA':Masterinstrumentslist_list,  
                    'CurDateNow':datetime.now(),
                    'TservicehistoryActive':TservicehistoryActive,
                    'lPlantId':lPlantId,  
                    '30DateNow':datetime.now() + timedelta(days=30),  
                    'AreaofUselist_list':AreaofUselist_list,
                    'Adminunitlist_list':Adminunitlist_list,
                    'title':'User list', 
                    'message':'Your User list page.',
                    'sPlantName': sPlantName , 
                    'Location': 0 , 
                    'semployeename':  semployeename,
                    'txtSearch': "" , 
                    'sCodeFinal1': "" ,  
                    'sCodeFinal2': "" ,  
                    'cmbClassificationID': 0 , 
                    'cmbCategoryID': 0 ,  
                    'cmbFlow1ID': 0 ,  
                    'cmbFlow2ID': 0 ,  
                    'cmbFlow3ID': 0 ,  
                    'cmbFlow4ID': 0 ,
                    'cmbFlow5ID': 0 ,     
                    'cmbFlow1label': "",  
                    'cmbFlow2label': "",  
                    'cmbFlow3label': "",  
                    'cmbFlow4label': "",
                    'cmbFlow5label': "",  
                    'bNewID': 0 ,   
                    'bSAPCodeDone': bSAPCodeDone, 
                    'bSAPCodeNotDone': bSAPCodeNotDone,  
                    'sIssueDate': sIssueDate, 
                }) 


                
            TservicehistorySave = Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            
            linstrumentid = lID
            lscheduleid = 0
            sinstrumentcode = ""
            sinstrumentdesc = ""
            Masterinstrumentslist_listAQW =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            if Masterinstrumentslist_listAQW:                
                sinstrumentid = Masterinstrumentslist_listAQW.sinstrumentid
                sinstrumentDesc = Masterinstrumentslist_listAQW.sdescription
            sinstrumentcode=sinstrumentid
            historyserviceid = 0

            brepair = 1
            scurrentstatus = cmbReturnStatus 
            dtservicedate = txtRepairDate
            # fservicecost = 0
            # stimetaken = "" 
            lenteredid = 0
            senteredby = request.session['semployeeno'] + "|" + request.session['semployeename']
            lenteredid =  request.session['lLoginUserId']
            # lapprovedid = 0
            # sapprovedby = ""
            # dtapprovaldate = datetime.today()
            # scertificateno = ""
            # scomments = ""
            # lservicevendorid = 0
            # sservicevendor = ""
            # spurchaseorderno = ""
            # sservicecertificatefile = ""
            # sservicecertificatepath = ""
            # dtdispatchdate = datetime.today()
            # dtduedate = datetime.today()
            # lusedbyid = request.session['lLoginUserId']
            # susedbyname = request.session['semployeeno'] + "|" + request.session['semployeename']
            # bapproved = 0
            # brefdatail = 0
            # dvendor = datetime.today()
            # drefdate = datetime.today()
            # lplantid = request.session['lunitid']
            # splantname = request.session['sunitno']
            # splantcode = ""
            # lcompanyid = 0
            # lnoticedbyid = 0
            # snoticedbyname = ""
            # sreason = ""
            # dtdateofnotice = datetime.today()
            # llocationid = 0
            # slocationname = ""
            # brejected = 0
            # bsentforrepair = 0
            # ldcrefid = 0
            # sservicedate = ""
            # sapprovaldate = ""
            # sdispatchdate = ""
            # sduedate = ""
            # srefdate = ""
            # sdateofnotice = ""
            # bdvendor = 0
            # sservicecertificatefile1 = ""
            # sservicecertificatefile2 = ""
            # sservicecertificatefile3 = ""
            # sservicecertificatefile4 = ""
            # sservicecertificatefile5 = ""
            fpmcost = 0
            fpmcost =txtRepairCost
            scauseofdamage = txtCauseofDamage
            srepairdetails = txtRepairDetails
            srepairdoneby = txtRepairDoneBy
            srepairpodcref = txtRepairRefNo
            srepairdcdate = ""
            srepairreturnrefno = txtRepairVendorRef
            srepairreturndate = ""

            Masterinstrumentslist_listSaveDamaged =  Masterinstrumentslist.objects.get(  lid=linstrumentid)
            historyserviceid = Masterinstrumentslist_listSaveDamaged.lrepairid 
            TservicehistoryUpdate =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)

            TservicehistoryUpdate.scauseofdamage = scauseofdamage
            TservicehistoryUpdate.srepairdetails = srepairdetails
            TservicehistoryUpdate.srepairdoneby = srepairdoneby
            TservicehistoryUpdate.srepairpodcref = txtRepairRefNo 
            TservicehistoryUpdate.srepairreturnrefno = txtRepairVendorRef 

            TservicehistoryUpdate.scurrentstatus = scurrentstatus 
            TservicehistoryUpdate.dtservicedate = dtservicedate 
            if(TservicehistoryUpdate.lenteredid == 0):
                TservicehistoryUpdate.senteredby = senteredby
                TservicehistoryUpdate.lenteredid =  lenteredid 
            TservicehistoryUpdate.sapprovedby = senteredby
            TservicehistoryUpdate.lapprovedid =  lenteredid 
            TservicehistoryUpdate.bapproved = 1
            TservicehistoryUpdate.fpmcost = fpmcost 

            TservicehistoryUpdate.save()

            if(scurrentstatus == "ACCEPT & UNDER CALIBRATION"):
                # Masterinstrumentslist_listSaveDamaged.scurrentstatus="UNDER CALIBRATION"
                l=0
            else:
                Masterinstrumentslist_listSaveDamaged.scurrentstatus= scurrentstatus
                

            Masterinstrumentslist_listSaveDamaged.lrepairid =0
            Masterinstrumentslist_listSaveDamaged.bunderrepair =0
            Masterinstrumentslist_listSaveDamaged.save()



            ThistorytransactionsSave = Thistorytransactions(linstrumentid  = linstrumentid )
            ThistorytransactionsSave.save() 

                    
            lTransID =0
            lTransID = ThistorytransactionsSave.lid
            ThistorytransactionsSaveUpdate =  Thistorytransactions.objects.get(lid =lTransID) 

            ThistorytransactionsSaveUpdate.lhistorymainid=historyserviceid
            ThistorytransactionsSaveUpdate.linstrumentid=linstrumentid
            ThistorytransactionsSaveUpdate.shistorytype="Service"
            ThistorytransactionsSaveUpdate.scalibrationvendor=srepairdoneby
            ThistorytransactionsSaveUpdate.scalibrationvendorid="0"
            ThistorytransactionsSaveUpdate.senteredby=senteredby
            ThistorytransactionsSaveUpdate.scalibrationresult=""
            ThistorytransactionsSaveUpdate.scurrentstatus=scurrentstatus
            ThistorytransactionsSaveUpdate.dtcalibrationdate=txtRepairDate
            ThistorytransactionsSaveUpdate.fcalibcost=0
            ThistorytransactionsSaveUpdate.llplantid=lPlantId
            ThistorytransactionsSaveUpdate.ssplantname=sPlantName
            ThistorytransactionsSaveUpdate.slplantcode=""
            ThistorytransactionsSaveUpdate.lcompanyid=lcompanyid
            ThistorytransactionsSaveUpdate.dtreturneddate=txtRepairDate
            ThistorytransactionsSaveUpdate.sinstrumentcode=sinstrumentcode
            
            ThistorytransactionsSaveUpdate.sdesc= sinstrumentdesc
            ThistorytransactionsSaveUpdate.sto=""
            ThistorytransactionsSaveUpdate.sfrom=""
            ThistorytransactionsSaveUpdate.dthistorydate=txtRepairDate
            ThistorytransactionsSaveUpdate.shistorydate=txtRepairDate
            ThistorytransactionsSaveUpdate.sreturneddate=txtRepairDate
            ThistorytransactionsSaveUpdate.llineid=0 
            ThistorytransactionsSaveUpdate.slinename=""

            scomment = "Cause of Damage : " + txtCauseofDamage + " | Repair Details : " + txtRepairDetails + " | Repair Sent Doc Details (PO/DC) : " + txtRepairRefNo  + " | Repair Done : " + txtRepairDoneBy   + " | Return Doc Ref. : " + txtRepairVendorRef    + " | Status : " + scurrentstatus  

            ThistorytransactionsSaveUpdate.scomment=scomment
            ThistorytransactionsSaveUpdate.lpartid=0
            ThistorytransactionsSaveUpdate.spartno=""
            ThistorytransactionsSaveUpdate.loperatorid=0
            ThistorytransactionsSaveUpdate.sissuedoperator=""
            ThistorytransactionsSaveUpdate.sporef=txtRepairRefNo
            ThistorytransactionsSaveUpdate.sreason=txtCauseofDamage



            ThistorytransactionsSaveUpdate.save()


 

            return redirect('CalibrationStart', lID=linstrumentid ) 
            


    else:

        Masterinstrumentslist_listA =  Masterinstrumentslist.objects.get(  lid=lID)
        if Masterinstrumentslist_listA:

            if(Masterinstrumentslist_listA.bunderrepair == 1):
                historyserviceid =0
                linstrumentid = lID
                historyserviceid = Masterinstrumentslist_listA.lrepairid
                Tservicehistory_listA =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)
                if Tservicehistory_listA:

                    if(Tservicehistory_listA.bapproved == 1):
                        
                        historyserviceid =0

                        linstrumentid = lID
                        lscheduleid = 0
                        sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                        sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                        brepair = 0
                        scurrentstatus = ""
                        sserviceresult = ""
                        dtservicedate = datetime.now()
                        fservicecost = 0
                        stimetaken = ""
                        sdevicecondition = ""
                        lenteredid = 0
                        senteredby = ""
                        lapprovedid = 0
                        sapprovedby = ""
                        dtapprovaldate = datetime.now()
                        scertificateno = ""
                        scomments = ""
                        lservicevendorid = 0
                        sservicevendor = ""
                        spurchaseorderno = ""
                        sservicecertificatefile = ""
                        sservicecertificatepath = ""
                        dtdispatchdate = datetime.now()
                        dtduedate = datetime.now()
                        lusedbyid = 0
                        susedbyname = ""
                        bapproved = 0
                        brefdatail = 0
                        dvendor = datetime.now()
                        drefdate = datetime.now()
                        fpmcost = 0
                        lplantid = 0
                        splantname = ""
                        splantcode = ""
                        lcompanyid = 0
                        lnoticedbyid = 0
                        snoticedbyname = ""
                        sreason = ""
                        dtdateofnotice = datetime.now()
                        llocationid = 0
                        slocationname = ""
                        brejected = 0
                        bsentforrepair = 0
                        ldcrefid = 0
                        sservicedate = ""
                        sapprovaldate = ""
                        sdispatchdate = ""
                        sduedate = ""
                        srefdate = ""
                        sdateofnotice = ""
                        bdvendor = 0


                                
                        TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                        TservicehistorySave.save()
                        historyserviceid = TservicehistorySave.historyserviceid

                        Masterinstrumentslist_listA.bunderrepair =1
                        Masterinstrumentslist_listA.lrepairid =historyserviceid
                        Masterinstrumentslist_listA.save()
                
                    else:
                        
                        historyserviceid = Tservicehistory_listA.historyserviceid

                else:


                    linstrumentid = lID
                    lscheduleid = 0
                    sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                    sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                    brepair = 0
                    scurrentstatus = ""
                    sserviceresult = ""
                    dtservicedate = datetime.now()
                    fservicecost = 0
                    stimetaken = ""
                    sdevicecondition = ""
                    lenteredid = 0
                    senteredby = ""
                    lapprovedid = 0
                    sapprovedby = ""
                    dtapprovaldate = datetime.now()
                    scertificateno = ""
                    scomments = ""
                    lservicevendorid = 0
                    sservicevendor = ""
                    spurchaseorderno = ""
                    sservicecertificatefile = ""
                    sservicecertificatepath = ""
                    dtdispatchdate = datetime.now()
                    dtduedate = datetime.now()
                    lusedbyid = 0
                    susedbyname = ""
                    bapproved = 0
                    brefdatail = 0
                    dvendor = datetime.now()
                    drefdate = datetime.now()
                    fpmcost = 0
                    lplantid = 0
                    splantname = ""
                    splantcode = ""
                    lcompanyid = 0
                    lnoticedbyid = 0
                    snoticedbyname = ""
                    sreason = ""
                    dtdateofnotice = datetime.now()
                    llocationid = 0
                    slocationname = ""
                    brejected = 0
                    bsentforrepair = 0
                    ldcrefid = 0
                    sservicedate = ""
                    sapprovaldate = ""
                    sdispatchdate = ""
                    sduedate = ""
                    srefdate = ""
                    sdateofnotice = ""
                    bdvendor = 0


                            
                    TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                    TservicehistorySave.save()
                    historyserviceid = TservicehistorySave.historyserviceid

                    Masterinstrumentslist_listA.bunderrepair =1
                    Masterinstrumentslist_listA.lrepairid =historyserviceid
                    Masterinstrumentslist_listA.save()


            if(Masterinstrumentslist_listA.bunderrepair == 0):
                historyserviceid = 0




                linstrumentid = lID
                lscheduleid = 0
                sinstrumentcode = Masterinstrumentslist_listA.sinstrumentcode
                sinstrumentdesc = Masterinstrumentslist_listA.sdescription
                brepair = 0
                scurrentstatus = ""
                sserviceresult = ""
                dtservicedate = datetime.now()
                fservicecost = 0
                stimetaken = ""
                sdevicecondition = ""
                lenteredid = 0
                senteredby = ""
                lapprovedid = 0
                sapprovedby = ""
                dtapprovaldate = datetime.now()
                scertificateno = ""
                scomments = ""
                lservicevendorid = 0
                sservicevendor = ""
                spurchaseorderno = ""
                sservicecertificatefile = ""
                sservicecertificatepath = ""
                dtdispatchdate = datetime.now()
                dtduedate = datetime.now()
                lusedbyid = 0
                susedbyname = ""
                bapproved = 0
                brefdatail = 0
                dvendor = datetime.now()
                drefdate = datetime.now()
                fpmcost = 0
                lplantid = 0
                splantname = ""
                splantcode = ""
                lcompanyid = 0
                lnoticedbyid = 0
                snoticedbyname = ""
                sreason = ""
                dtdateofnotice = datetime.now()
                llocationid = 0
                slocationname = ""
                brejected = 0
                bsentforrepair = 0
                ldcrefid = 0
                sservicedate = ""
                sapprovaldate = ""
                sdispatchdate = ""
                sduedate = ""
                srefdate = ""
                sdateofnotice = ""
                bdvendor = 0


                         
                TservicehistorySave = Tservicehistory(linstrumentid = linstrumentid, 	lscheduleid = lscheduleid, 	sinstrumentcode = sinstrumentcode, 	sinstrumentdesc = sinstrumentdesc, 	brepair = brepair, 	scurrentstatus = scurrentstatus, 	sserviceresult = sserviceresult, 	dtservicedate = dtservicedate, 	fservicecost = fservicecost, 	stimetaken = stimetaken, 	sdevicecondition = sdevicecondition, 	lenteredid = lenteredid, 	senteredby = senteredby, 	lapprovedid = lapprovedid, 	sapprovedby = sapprovedby, 	dtapprovaldate = dtapprovaldate, 	scertificateno = scertificateno, 	scomments = scomments, 	lservicevendorid = lservicevendorid, 	sservicevendor = sservicevendor, 	spurchaseorderno = spurchaseorderno, 	sservicecertificatefile = sservicecertificatefile, 	sservicecertificatepath = sservicecertificatepath, 	dtdispatchdate = dtdispatchdate, 	dtduedate = dtduedate, 	lusedbyid = lusedbyid, 	susedbyname = susedbyname, 	bapproved = bapproved, 	brefdatail = brefdatail, 	dvendor = dvendor, 	drefdate = drefdate, 	fpmcost = fpmcost, 	lplantid = lplantid, 	splantname = splantname, 	splantcode = splantcode, 	lcompanyid = lcompanyid, 	lnoticedbyid = lnoticedbyid, 	snoticedbyname = snoticedbyname, 	sreason = sreason, 	dtdateofnotice = dtdateofnotice, 	llocationid = llocationid, 	slocationname = slocationname, 	brejected = brejected, 	bsentforrepair = bsentforrepair, 	ldcrefid = ldcrefid, 	sservicedate = sservicedate, 	sapprovaldate = sapprovaldate, 	sdispatchdate = sdispatchdate, 	sduedate = sduedate, 	srefdate = srefdate, 	sdateofnotice = sdateofnotice, 	bdvendor = bdvendor)

                TservicehistorySave.save()
                historyserviceid = TservicehistorySave.historyserviceid

                Masterinstrumentslist_listA.bunderrepair =1
                Masterinstrumentslist_listA.lrepairid =historyserviceid
                Masterinstrumentslist_listA.save()

 
         
        AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
        if AdminunitlistActive:
            sPlantCode = AdminunitlistActive.splantno
            sPlantNameName = AdminunitlistActive.splantname + " (" + AdminunitlistActive.scode.strip() + ")"
            sPlantNameNameA = AdminunitlistActive.splantname

        request.session['sPlantCode']   =sPlantCode
         
        lunitidA=request.session['lunitid']  
        AreaofUselist_list = Adminlocationlist.objects.filter(lplantid=lunitidA).order_by('slocationname').values()     

        Masterinstrumentslist_list =  Masterinstrumentslist.objects.get(  lid=lID)
 
         
        Adminunitlist_list = Adminunitlist.objects.order_by('splantno')

        TservicehistoryActive = Tservicehistory.objects.get(historyserviceid=historyserviceid) 
        

 
        return render(request, "CloudCaliber/GaugeServiceRepair.html", 
        {
            'Masterinstrumentslist_listA':Masterinstrumentslist_list,  
            'CurDateNow':datetime.now(),
            'TservicehistoryActive':TservicehistoryActive,
            'lPlantId':lPlantId,  
            '30DateNow':datetime.now() + timedelta(days=30),  
            'AreaofUselist_list':AreaofUselist_list,
            'Adminunitlist_list':Adminunitlist_list,
            'title':'User list', 
            'message':'Your User list page.',
            'sPlantName': sPlantName , 
            'Location': 0 , 
            'semployeename':  semployeename,
            'txtSearch': "" , 
            'sCodeFinal1': "" ,  
            'sCodeFinal2': "" ,  
            'cmbClassificationID': 0 , 
            'cmbCategoryID': 0 ,  
            'cmbFlow1ID': 0 ,  
            'cmbFlow2ID': 0 ,  
            'cmbFlow3ID': 0 ,  
            'cmbFlow4ID': 0 ,
            'cmbFlow5ID': 0 ,     
            'cmbFlow1label': "",  
            'cmbFlow2label': "",  
            'cmbFlow3label': "",  
            'cmbFlow4label': "",
            'cmbFlow5label': "",  
            'bNewID': 0 ,  
             
            'bSAPCodeDone': bSAPCodeDone, 
            'bSAPCodeNotDone': bSAPCodeNotDone,  
            'sIssueDate': sIssueDate, 
        }) 


 

def GaugeServiceRepairHistory(request, lID):
    

    if request.session:
        lLoginUserId = request.session['lLoginUserId'] 
        if(lLoginUserId==0):
            return   redirect('home') 
    else:
        return   redirect('home')  

        
    sCodeFinal1 = ""
    sCodeFinal2 = ""
 
    historyserviceid = 0
    

    historyserviceid = 0
    linstrumentid = 0
    lscheduleid = 0
    sinstrumentcode = ""
    sinstrumentdesc = ""
    brepair = 0
    scurrentstatus = ""
    sserviceresult = ""
    dtservicedate = datetime.today()
    fservicecost = 0
    stimetaken = ""
    sdevicecondition = ""
    lenteredid = 0
    senteredby = ""
    lapprovedid = 0
    sapprovedby = ""
    dtapprovaldate = datetime.today()
    scertificateno = ""
    scomments = ""
    lservicevendorid = 0
    sservicevendor = ""
    spurchaseorderno = ""
    sservicecertificatefile = ""
    sservicecertificatepath = ""
    dtdispatchdate = datetime.today()
    dtduedate = datetime.today()
    lusedbyid = 0
    susedbyname = ""
    bapproved = 0
    brefdatail = 0
    dvendor = datetime.today()
    drefdate = datetime.today()
    fpmcost = 0
    lplantid = 0
    splantname = ""
    splantcode = ""
    lcompanyid = 0
    lnoticedbyid = 0
    snoticedbyname = ""
    sreason = ""
    dtdateofnotice = datetime.today()
    llocationid = 0
    slocationname = ""
    brejected = 0
    bsentforrepair = 0
    ldcrefid = 0
    sservicedate = ""
    sapprovaldate = ""
    sdispatchdate = ""
    sduedate = ""
    srefdate = ""
    sdateofnotice = ""
    bdvendor = 0





    request.session['InstIDRepair']  = 0

    lPlantIdSelect = 0
    lPlantId = request.session['lunitid']  
    sPlantName = request.session['sunitno'] 
    lcompanyid = request.session['lcompanyid']  
    scompantname =  request.session['scompantname']  
    request.session['sPlantCode']   = ""
 
    lCategoryID = request.session['lCategoryID']                       
    lLoginUserId = request.session['lLoginUserId']  
    semployeename = request.session['semployeename'] 
    semployeeno = request.session['semployeeno']  
    lunitid = request.session['lunitid']  
    sunitno = request.session['sunitno']  
    lcompanyid = request.session['lcompanyid']  
    scompantname = request.session['scompantname']  
    semailaddress = request.session['semailaddress']  
    smobile = request.session['smobile']  
    

    # if request.session:
    #     request.session.clear()
 
 
    request.session['InstIDRepair']  = 0
    request.session['bSAPCodeDone']  = 0
    request.session['bSAPCodeNotDone']  = 0
    request.session['ID_Categories']  = 0
    request.session['ClassificationData']  = 0
    request.session['Flow1Data']  = 0
    request.session['Flow2Data']  = 0
    request.session['Flow3Data']  = 0
    request.session['Flow4Data']  = 0
    request.session['Flow5Data']  = 0
    request.session['GaugeClass']  = 0
    request.session['Location']  = 0 
    request.session['txtSearch']  = "" 

    CurDateFrom = datetime.today().strftime('%d-%m-%Y')
    request.session['CurDateFrom']  = CurDateFrom
    request.session['CurDateTo']  = CurDateFrom
    
    request.session['lCategoryID'] = lCategoryID                        
    request.session['lLoginUserId'] = lLoginUserId
    request.session['semployeename'] = semployeename
    request.session['semployeeno'] = semployeeno
    request.session['lunitid'] = lunitid
    request.session['sunitno']  = sunitno
    request.session['lcompanyid']  = lcompanyid
    request.session['scompantname']  = scompantname
    request.session['semailaddress'] = semailaddress
    request.session['smobile']  = smobile

    #semployeename = semployeeno + " | " + semployeename
    request.session['badmin'] =0
    request.session['badmin1'] = 0
    request.session['bstores'] = 0
    request.session['bcalibration'] = 0
    request.session['bservice'] = 0
    request.session['bmsa'] = 0
    request.session['bmasterlistonlyallplant'] = 1  
    request.session['breadonly'] =0
    sPlantCode = ""
    sCategoryCode = ""
    lcontinuousnob  = ""
    bFlow = 0
    sFlowName  = ""
    lcontinuousnoa  =0
    bFlow1 = 0
    sFlowName1  = ""
    lcontinuousnoa1  = 0
    bFlow2 = 0
    sFlowName2  = ""
    lcontinuousnoa2  =0
    bFlow3 = 0
    sFlowName3  = ""
    lcontinuousnoa3  =0
    bFlow4 = 0
    sFlowName4  = ""
    lcontinuousnoa4  =0
    bFlow5 = 0
    sFlowName5  = ""
    lcontinuousnoa5  =0
    bFlow6 = 0
    sFlowName6  = ""
    lcontinuousnoa6  =0
    bFlow7 = 0
    sFlowName7  = ""
    lcontinuousnoa7  =0
    bFlow8 = 0
    sFlowName8  = ""
    lcontinuousnoa8  =0
    bFlow9 = 0
    sFlowName9  = ""
    lcontinuousnoa9  =0
    bFlow10 = 0
    sFlowName10  = ""
    lcontinuousnoa10  =0
    
    bSAPCodeDone = 0
    bSAPCodeNotDone = 0

    cmbClassificationID = 0
    cmbCategoryID = 0
    cmbgetFlow1ID = 0
    cmbgetFlow2ID = 0
    cmbgetFlow3ID = 0
    cmbgetFlow4ID = 0
    cmbgetFlow5ID = 0
    cmbgetFlow6ID = 0
    

    sIssueDate3 = ""
    sIssueDate2 = ""
    sIssueDate1 = ""
    sIssueDate = "" 
    dtIssueDate = datetime.now()
    sIssueDate1 = str(datetime.now()) 
    sIssueDate = sIssueDate1[0:10]


    getFlow1Code = ""
    request.session['getFlow1Code']  =getFlow1Code
    getFlow2Code = ""
    request.session['getFlow2Code']  =getFlow2Code
    getFlow3Code = ""
    request.session['getFlow3Code']  =getFlow3Code
    getFlow4Code = ""
    request.session['getFlow4Code']  =getFlow4Code
    getFlow5Code = ""
    request.session['getFlow5Code']  =getFlow5Code
    getFlowContCode = ""
    request.session['getFlowContCode']  =getFlowContCode


    bContFlag = 0
    request.session['bContFlag'] =bContFlag

    request.session['cmbClassificationID'] =cmbClassificationID
    request.session['cmbCategoryID'] =cmbCategoryID
    request.session['cmbgetFlow1ID'] =cmbgetFlow1ID
    request.session['cmbgetFlow2ID'] =cmbgetFlow2ID
    request.session['cmbgetFlow3ID'] =cmbgetFlow3ID
    request.session['cmbgetFlow4ID'] =cmbgetFlow4ID
    request.session['cmbgetFlow5ID'] =cmbgetFlow5ID
    request.session['cmbgetFlow6ID'] =cmbgetFlow6ID

    AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
    if AdminunitlistActive:
        sPlantCode = AdminunitlistActive.splantno
 
    request.session['sPlantCode']   =sPlantCode

    sCodeFinal1=""
    sCodeFinal2="-" + sPlantCode

    historyserviceid = lID
    
    Tservicehistory_listAGET =  Tservicehistory.objects.get(  historyserviceid=historyserviceid)
    if Tservicehistory_listAGET:
        
        linstrumentid = Tservicehistory_listAGET.linstrumentid 
 




        
    AdminunitlistActive = Adminunitlist.objects.get(lplantid=lPlantId) 
    if AdminunitlistActive:
        sPlantCode = AdminunitlistActive.splantno
        sPlantNameName = AdminunitlistActive.splantname + " (" + AdminunitlistActive.scode.strip() + ")"
        sPlantNameNameA = AdminunitlistActive.splantname

    request.session['sPlantCode']   =sPlantCode
    
    Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
    if(sFlowName1 == "Part No1"):
        Adminassetcategorytypelist1_AddNewOBJ1 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
    else:
        Adminassetcategorytypelist1_AddNewOBJ1 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=1 ).values()
        
    if(sFlowName1 == "Part No1"):
        Adminassetcategorytypelist1_AddNewOBJ2 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
    else: 
        Adminassetcategorytypelist1_AddNewOBJ2 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=2 ).values()
        
    if(sFlowName1 == "Part No1"):
        Adminassetcategorytypelist1_AddNewOBJ3 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
    else:  
        Adminassetcategorytypelist1_AddNewOBJ3 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=3 ).values()

    if(sFlowName1 == "Part No1"):
        Adminassetcategorytypelist1_AddNewOBJ4 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
    else:  
        Adminassetcategorytypelist1_AddNewOBJ4 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=4 ).values()

    if(sFlowName1 == "Part No1"):
        Adminassetcategorytypelist1_AddNewOBJ5 =  Adminpartdetailslist.objects.filter(lcompanyid=lcompanyid).order_by('spartno').values()
    else:  
        Adminassetcategorytypelist1_AddNewOBJ5 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=5 ).values()

    Adminassetcategorytypelist1_AddNewOBJ6 =  Adminassetcategorytypelist1.objects.filter(lcategorytype1=cmbCategoryID, lcode5=6 ).values()

    Admintoleranceclasslist_list =  Admintoleranceclasslist.objects.order_by('stoleranceclass')
    
    Adminassettypelist_list =  Adminassetcategorytypelist.objects.order_by('scategorytype')
    lunitidA=request.session['lunitid']  
    AreaofUselist_list = Adminlocationlist.objects.filter(lplantid=lunitidA).order_by('slocationname').values()     

    Masterinstrumentslist_list =  Masterinstrumentslist.objects.get(  lid=linstrumentid)

        
    Adminunitlist_list = Adminunitlist.objects.order_by('splantno')

    TservicehistoryActive = Tservicehistory.objects.get(historyserviceid=historyserviceid) 
    


    return render(request, "CloudCaliber/GaugeServiceRepairHistory.html", 
    {
        'Masterinstrumentslist_listA':Masterinstrumentslist_list,  
        'CurDateNow':datetime.now(),
        'TservicehistoryActive':TservicehistoryActive,
        'lPlantId':lPlantId,  
        '30DateNow':datetime.now() + timedelta(days=30),  
        'AreaofUselist_list':AreaofUselist_list,
        'Adminunitlist_list':Adminunitlist_list,
        'title':'User list', 
        'message':'Your User list page.',
        'sPlantName': sPlantName , 
        'Location': 0 , 
        'semployeename':  semployeename,
        'txtSearch': "" , 
        'sCodeFinal1': "" ,  
        'sCodeFinal2': "" ,  
        'cmbClassificationID': 0 , 
        'cmbCategoryID': 0 ,  
        'cmbFlow1ID': 0 ,  
        'cmbFlow2ID': 0 ,  
        'cmbFlow3ID': 0 ,  
        'cmbFlow4ID': 0 ,
        'cmbFlow5ID': 0 ,     
        'cmbFlow1label': "",  
        'cmbFlow2label': "",  
        'cmbFlow3label': "",  
        'cmbFlow4label': "",
        'cmbFlow5label': "",  
        'bNewID': 0 ,  
        'Adminassettypelist_list':Adminassettypelist_list,
        'bSAPCodeDone': bSAPCodeDone, 
        'bSAPCodeNotDone': bSAPCodeNotDone,  
        'sIssueDate': sIssueDate, 
    }) 
